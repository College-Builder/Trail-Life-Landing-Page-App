# Trail-Life-Landing-Page
A empresa de transporte fictícia "Trail Life" foi desenvolvida como parte do projeto integrador do terceiro semestre na Universidade de Sorocaba pelo grupo de alunos que estão aqui neste repositório. Este repositório abriga o código da aplicação backend, que inclui o site da Trail Life e uma API para envio de emails aos clientes.
